# VexChess — başlangıç web arayüzü

## İçerik
- `index.html`: mobil uyumlu, dikey kaydırmalı açılış ekranı ve giriş/kayıt arayüzü
- `assets/vexchess-logo.jpeg`: sağlanan VexChess logosu

## GitHub Codespaces'te çalıştırma
1. Bu ZIP'i aç ve dosyaları bir GitHub deposuna yükle.
2. Depoyu Codespaces ile aç.
3. Dosyaların bulunduğu klasörde terminalden `python3 -m http.server 8000` komutunu çalıştır.
4. Codespaces'in **Ports** bölümünde 8000 portunu **Open in Browser** ile aç.

## GitHub Pages'te yayımlama
Dosyaları deponun kök dizinine koy. GitHub deposunda **Settings → Pages** bölümünden `Deploy from a branch`, `main` ve `/(root)` seçip kaydet.

## Önemli sınır
Bu ilk sürüm yalnızca arayüz ve tarayıcıda çalışan bir demo hesap akışı içerir. Hesap bilgileri `localStorage` içinde tutulduğu için güvenli gerçek kullanıcı hesabı olarak kullanılmamalıdır; başka cihazlarda paylaşılmaz ve çevrim içi arkadaş/oda/satranç senkronizasyonu içermez. Gerçek yayın için sunucu tabanlı kimlik doğrulama ve gerçek zamanlı backend eklenmelidir.
